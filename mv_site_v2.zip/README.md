# Site de venda de MV – Moderno Roleplay (v2)

Agora com **quantidade dinâmica** (slider) e cálculo automático de preço (1 R$ = 1.000 MV).

## Novidades

* **Slider** permite escolher de 1.000 MV a 100.000 MV (ajuste nas variáveis).
* **Preço** mostrado em tempo real.
* **FAQ** embutido.
* **Layout** com barra de navegação e estilo responsivo Tailwind‑like sem dependências.

## Uso rápido

```bash
composer install
php -S localhost:8000
```

Abra <http://localhost:8000>.

## Configuração

Edite `config.php` e insira:
* `MP_ACCESS_TOKEN` (MercadoPago)
* `PRICE_PER_1000` (atualize se mudar conversão)

## Observação

A lógica de entrega de MV deve ser adicionada no `webhook.php`, conectando ao banco ou bot SA:MP.
