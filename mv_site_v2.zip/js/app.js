const qtyEl = document.getElementById('qty');
const priceEl = document.getElementById('price');
const qtyLabel = document.getElementById('qtyLabel');
const PRICE_PER_1000 = 1.0;

function formatNumber(n) {
  return n.toLocaleString('pt-BR');
}

function updatePrice() {
  const qty = parseInt(qtyEl.value, 10);
  qtyLabel.textContent = formatNumber(qty);
  const price = (qty / 1000 * PRICE_PER_1000).toFixed(2);
  priceEl.textContent = price.replace('.', ',');
}
updatePrice();

document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('buyForm');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = new FormData(form);
  const resp = await fetch('process_payment.php', { method: 'POST', body: formData });
  if (!resp.ok) { alert('Erro ao criar pagamento'); return; }
  const data = await resp.json();
  document.getElementById('qrImg').src = 'data:image/png;base64,' + data.qr_code;
  document.getElementById('copyPaste').value = data.copy_paste;
  document.getElementById('pixInfo').classList.remove('hidden');
});
