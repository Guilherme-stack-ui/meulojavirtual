<?php
// config.php
define('MP_ACCESS_TOKEN', 'INSIRA_SEU_ACCESS_TOKEN_AQUI');

// Preço por 1.000 MV
define('PRICE_PER_1000', 1.0);
?>
