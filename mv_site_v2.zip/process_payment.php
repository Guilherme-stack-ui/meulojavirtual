<?php
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/config.php';

MercadoPago\SDK::setAccessToken(MP_ACCESS_TOKEN);

$nick  = $_POST['nick']  ?? '';
$email = $_POST['email'] ?? 'comprador@example.com';
$qty   = intval($_POST['qty'] ?? 0); // quantidade de MV

if ($qty < 1000 || $qty > 100000) {
  http_response_code(422);
  echo json_encode(['error' => 'Quantidade inválida']);
  exit;
}

$amount = ($qty / 1000) * PRICE_PER_1000;

$payment = new MercadoPago\Payment();
$payment->transaction_amount = (float) $amount;
$payment->description        = "{$qty} MV para {$nick}";
$payment->payment_method_id  = 'pix';
$payment->payer = ['email' => $email];
$payment->save();

if ($payment->status == 'pending') {
  header('Content-Type: application/json');
  echo json_encode([
    'qr_code'   => $payment->point_of_interaction->transaction_data->qr_code_base64,
    'copy_paste'=> $payment->point_of_interaction->transaction_data->qr_code,
    'id'        => $payment->id
  ]);
} else {
  http_response_code(500);
  echo json_encode(['error' => 'Falha ao criar pagamento']);
}
?>
