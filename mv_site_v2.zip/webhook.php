<?php
$input = file_get_contents('php://input');
file_put_contents(__DIR__ . '/webhook.log', date('c') . ' ' . $input . PHP_EOL, FILE_APPEND);
http_response_code(200);
// TODO: consultar pagamento via API, validar assinatura e entregar MV
?>
